package edu.uni.ygoduellite.api;

import edu.uni.ygoduellite.model.Card;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class YgoApiClient {
    private static final String RANDOM_CARD_URL = "https://db.ygoprodeck.com/api/v7/randomcard.php";
    private final HttpClient client = HttpClient.newHttpClient();

    public Card fetchRandomMonsterCard() throws IOException, InterruptedException {
        for (int attempts = 0; attempts < 8; attempts++) {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(RANDOM_CARD_URL))
                    .GET()
                    .build();
            HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200) continue;
            JSONObject json = new JSONObject(resp.body());
            String type = json.optString("type", "");
            if (!type.toLowerCase().contains("monster")) continue;
            String name = json.optString("name", "Unknown");
            int atk = json.has("atk") && !json.isNull("atk") ? json.getInt("atk") : 0;
            int def = json.has("def") && !json.isNull("def") ? json.getInt("def") : 0;
            String imageUrl = null;
            if (json.has("card_images")) {
                JSONArray imgs = json.getJSONArray("card_images");
                if (imgs.length() > 0) {
                    JSONObject img = imgs.getJSONObject(0);
                    imageUrl = img.optString("image_url", null);
                }
            }
            return new Card(name, atk, def, imageUrl);
        }
        throw new IOException("No se obtuvo carta Monster tras varios intentos");
    }
}